package com.fannie.datepicker;

import static org.junit.Assert.*;

import java.util.concurrent.TimeUnit;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

import com.fannie.generic.GenericMethod1;
import com.fannie.generic.Itype;
import com.fannie.utils.WaitTypes;

public class DatePickerGeneric {

	private WebDriver driver;
	private String baseUrl;
	private GenericMethod1 gm1;
	private WaitTypes wt;
	@Before
	  public void setUp() throws Exception {
		System.setProperty("webdriver.chrome.driver", "C:\\selenium\\chrome\\chromedriver_win32\\chromedriver.exe");// this is the location where your driver is
	    driver = new ChromeDriver();
	    gm1 = new GenericMethod1(driver);
	    baseUrl = "http://expedia.com";
	    wt=new WaitTypes(driver);
	    
	    driver.manage().window().maximize();
	    driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);//wait for 30 secs, if this is commented out the test fails as after login email page won't stay
	  }
	  @After
	  public void tearDown() throws Exception {
		  Thread.sleep(3000);
	   driver.quit(); // quit the website after performing the function
	    
	} 
	@Test
	public void test() {
		driver.get(baseUrl);
		gm1.getElement("tab-flight-tab-hp",Itype.ID).click();// go to the tab flights
		 wt=new WaitTypes(driver);

		 WebElement inputElementSrc = gm1.getElement("flight-origin-hp-flight", "id");// enter the src
		  inputElementSrc.sendKeys("Washington, DC (WAS-All Airports)");
		  
		  WebElement inputElementDest = gm1.getElement("flight-destination-hp-flight", "id");// enter the dest
		  inputElementDest.sendKeys("Chennai, India");
		  
		// to select click on departing date picker and get the id
			driver.findElement(By.id("flight-departing-hp-flight")).click();
			
			WebElement srcDate=
					driver.findElement(By.xpath("//*[@id='flight-departing-wrapper-hp-flight']/div/div/div[2]/table/tbody/tr/td/button[text()='20']"));
			srcDate.click();
			driver.findElement(By.id("flight-returning-hp-flight")).click();
			WebElement destDate=
			driver.findElement(By.xpath("//*[@id='flight-returning-wrapper-hp-flight']/div/div/div[3]/table/tbody/tr/td/button[text()='12']"));
			destDate.click();
			//driver.findElement(By.id("flight-adults-hp-flight")).click();				
			Select selectAdult = new Select(driver.findElement(By.id("flight-adults-hp-flight")));
			selectAdult.selectByIndex(2);
			
			Select selectChild = new Select(driver.findElement(By.id("flight-children-hp-flight")));
			selectChild.selectByIndex(1);
			
			//wt.waitForElement(By.id("flight-age-select-"++"-label-hp-flight"), 3); //++ is iterating number 1,2,3, etc...
			
			//String selectString= new String ();
			
			
			
	}
}
