package com.fannie.datepicker;
//partial text search
import static org.junit.Assert.*;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

import com.fannie.generic.GenericMethod1;
import com.fannie.generic.Itype;
import com.fannie.utils.WaitTypes;

public class ExpediaGeneric {

	private WebDriver driver;
	private String baseUrl;
	//private GenericMethod1 gm1;
	
	@Before
	  public void setUp() throws Exception {
		System.setProperty("webdriver.chrome.driver", "C:\\selenium\\chrome\\chromedriver_win32\\chromedriver.exe");// this is the location where your driver is
	    driver = new ChromeDriver();
	    baseUrl = "http://expedia.com";
	
	    
	    driver.manage().window().maximize();
	    driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);//wait for 30 secs, if this is commented out the test fails as after login email page won't stay
	  }
	  @After
	  public void tearDown() throws Exception {
		  Thread.sleep(3000);
	   driver.quit(); // quit the website after performing the function
	    
	} 
	@Test
	public void test() throws InterruptedException {
		driver.get(baseUrl);
		String partialString ="new yor";
		String location="New York, NY (NYC-All Airports)"; // give you list of zero from 0 to n numbers
		
		driver.findElement(By.id("tab-flight-tab-hp")).click();
		driver.findElement(By.id("flight-origin-hp-flight")).sendKeys(partialString);
		
		//xpath for list of items-->//li@class='result-item']
		
		List<WebElement> elements = driver.findElements(By.xpath("//li[@class='results-item']"));
				
				System.out.println(" Location got is " + elements.size());
				
				for(WebElement element : elements ){
					System.out.println(element.getText());
				}
		
			/*	Thread.sleep(2000);
				for(WebElement element : elements ){ /// once location is found get locations
					if(element.getText().equals(location)){
					element.click();
				   }
				}*/
				
				// or you can do this way for partial text search
			Thread.sleep(2000);
				for(WebElement element : elements ){ /// once location is found get locations
					if(element.getText().startsWith("new yor")){
					element.click();
				   }
				}
				
		
}
}
