package com.fannie.datepicker;

import static org.junit.Assert.*;

import java.util.concurrent.TimeUnit;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import com.fannie.generic.GenericMethod1;
import com.fannie.utils.WaitTypes;

public class DatePickerTest {

	private WebDriver driver;
	private String baseUrl;
	private GenericMethod1 gm1;
	@Before
	  public void setUp() throws Exception {
		System.setProperty("webdriver.chrome.driver", "C:\\selenium\\chrome\\chromedriver_win32\\chromedriver.exe");// this is the location where your driver is
	    driver = new ChromeDriver();
	    gm1 = new GenericMethod1(driver);
	    baseUrl = "http://expedia.com";
	    //wt=new WaitTypes(driver);
	    
	    driver.manage().window().maximize();
	    driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);//wait for 30 secs, if this is commented out the test fails as after login email page won't stay
	  }
	  @After
	  public void tearDown() throws Exception {
		  Thread.sleep(2000);
	    driver.quit(); // quit the website after performing the function
	    
	} 

	  @Test
	  public void test() throws InterruptedException{
		  driver.get(baseUrl);
		  driver.findElement(By.id("tab-flight-tab-hp")).click();
		  String src ="Washington, DC (WAS-All Airports)";
		driver.findElement(By.id("flight-origin-hp-flight")).sendKeys(src);
		
		String dest ="San Francisco, California";
		driver.findElement(By.id("flight-destination-hp-flight")).sendKeys(dest); // put path in generic method for the assignment
		
		// to select click on departing date picker and get the id
		driver.findElement(By.id("flight-departing-hp-flight")).click();
		
		WebElement srcDate=
				driver.findElement(By.xpath("//*[@id='flight-departing-wrapper-hp-flight']/div/div/div[2]/table/tbody/tr/td/button[text()='20']"));
		
		srcDate.click();
	  }
	  

}
