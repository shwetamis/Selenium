package com.fannie.generic;

public interface Itype {
String XPATH ="xpath";
String ID ="id";
}
