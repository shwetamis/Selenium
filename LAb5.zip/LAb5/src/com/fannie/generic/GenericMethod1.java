package com.fannie.generic;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.WebDriverWait;

//this program will take locator and type and return web element
public class GenericMethod1 {
	WebDriver driver;
	public GenericMethod1(WebDriver driver){
		this.driver=driver; }
	public WebElement getElement(String locator, String type){
		WebElement element=null; // generic declaration of variable that returns a value
		type=type.toLowerCase();
		if(type.equals("id")){
			//System.out.println("Element found with id" + locator);
			element= this.driver.findElement(By.id(locator));
		}else if (type.equals("xpath")){
			element=  this.driver.findElement(By.xpath(locator));
		}else if (type.equals("css")){
			element=  this.driver.findElement(By.cssSelector(locator));
		}else if (type.equals("linktext")){
			element=  this.driver.findElement(By.linkText(locator));
		}
//		else{
//				System.out.println("sorry No location found");}
		
					return element;
		}
	
	public List<WebElement> getElementList(String locator, String type){
		type=type.toLowerCase();
		
		if(type.equals("id")){
			return this.driver.findElements(By.id(locator));
		
		}else if (type.equals("xpath")){
			return this.driver.findElements(By.xpath(locator));
		}else if (type.equals("css")){
			return this.driver.findElements(By.cssSelector(locator));
		}
		else if (type.equals("linktext")){
			return this.driver.findElements(By.linkText(locator));
		}


	System.out.println("sorry No location found");
			return null;
	}
	
	public boolean isElementFounc(String locator, String type){
		return this.getElementList(locator, type).size()>0;
	}
	public boolean checkSingleFound(String locator, String type){
		return this.getElementList(locator, type).size()==1; // atleast have 1 found
	}
	public WebDriverWait getWebDriverWait(long timeout)
	{
		return new WebDriverWait(driver, timeout);	
	}
	 
	public boolean checkKids(String locator, String type){
		
		if (this.getElementList(locator, type).size()==1)
				
		{
		   // do something
		}
		return false;
	}

}